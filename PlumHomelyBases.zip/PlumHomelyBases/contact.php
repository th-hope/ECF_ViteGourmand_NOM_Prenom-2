<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Vite & Gourmand</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <div class="logo" style="display: flex; align-items: center; color: white; font-weight: 600; font-size: 1.2rem;">
            <img src="logo.png" alt="Logo" style="height: 40px; margin-right: 10px;">
            Vite & Gourmand
        </div>
        <div class="nav-links">
            <a href="index.php">Accueil</a>
            <a href="index.php#menus">Menus</a>
            <a href="contact.php">Contact</a>
        </div>
    </nav>

    <div class="container" style="max-width: 800px; margin-top: 5rem;">
        <h1 style="text-align: center; color: var(--primary-color);">Contactez-nous</h1>
        <p style="text-align: center; margin-bottom: 3rem;">Julie & José sont à votre écoute pour organiser votre prochain événement à Bordeaux.</p>

        <div style="background: white; padding: 2.5rem; border-radius: var(--radius); box-shadow: var(--shadow);">
            <form action="#" method="POST" onsubmit="alert('Merci ! Julie & José vous recontacteront très vite.'); return false;">
                <div class="filter-group" style="margin-bottom: 1.5rem;">
                    <label for="nom">Nom complet</label>
                    <input type="text" id="nom" name="nom" required placeholder="Votre nom">
                </div>
                <div class="filter-group" style="margin-bottom: 1.5rem;">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required placeholder="votre@email.com">
                </div>
                <div class="filter-group" style="margin-bottom: 1.5rem;">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" required style="width: 100%; padding: 0.8rem; border: 2px solid #edf2f7; border-radius: var(--radius); font-family: inherit; min-height: 150px;" placeholder="Dites-nous en plus sur votre événement..."></textarea>
                </div>
                <button type="submit">Envoyer le message</button>
            </form>
        </div>

        <div style="margin-top: 4rem; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem; text-align: center;">
            <div>
                <h4 style="color: var(--primary-color);">Adresse</h4>
                <p>45 Rue des Grands Crus<br>33000 Bordeaux</p>
            </div>
            <div>
                <h4 style="color: var(--primary-color);">Téléphone</h4>
                <p>05 56 00 00 00</p>
            </div>
            <div>
                <h4 style="color: var(--primary-color);">Email</h4>
                <p>contact@viteetgourmand.fr</p>
            </div>
        </div>
    </div>

    <footer class="footer" style="margin-top: 5rem; padding: 4rem 2rem; background: var(--primary-color); color: white; border-radius: var(--radius) var(--radius) 0 0;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem;">
            <div>
                <h4 style="color: var(--secondary-color); margin-bottom: 1.5rem;">Vite & Gourmand</h4>
                <p style="color: #bdc3c7; font-size: 0.9rem;">Votre traiteur gastronomique à Bordeaux depuis 25 ans.</p>
            </div>
            <div>
                <h4 style="margin-bottom: 1.5rem;">Liens Rapides</h4>
                <ul style="list-style: none; padding: 0;">
                    <li style="margin-bottom: 0.5rem;"><a href="index.php" style="color: #bdc3c7; text-decoration: none; font-size: 0.9rem;">Accueil</a></li>
                    <li style="margin-bottom: 0.5rem;"><a href="index.php#menus" style="color: #bdc3c7; text-decoration: none; font-size: 0.9rem;">Nos Menus</a></li>
                    <li style="margin-bottom: 0.5rem;"><a href="contact.php" style="color: #bdc3c7; text-decoration: none; font-size: 0.9rem;">Contact</a></li>
                </ul>
            </div>
        </div>
        <div style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.1); text-align: center; color: #7f8c8d; font-size: 0.8rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
            <span>&copy; 2026 Vite & Gourmand. Tous droits réservés.</span>
            <span style="color: #bdc3c7;">Développé par <strong style="color: var(--secondary-color);">FAST DEV</strong></span>
        </div>
    </footer>
</body>
</html>
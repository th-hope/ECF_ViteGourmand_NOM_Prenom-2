# Replit Agent Guide

## Overview

This is a static frontend web application for a French catering/menu ordering service. It displays themed meal menus (Christmas, Easter, Classic, Family, etc.) with filtering capabilities. The app allows users to browse pre-defined menus with details like theme, dietary regime, number of people served, pricing, and food images. The project is built with vanilla HTML, CSS, and JavaScript — no frameworks or build tools.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Pure vanilla stack**: The app uses plain HTML, CSS, and JavaScript with no frontend framework (no React, Vue, etc.).
- **Data storage**: Menu data is hardcoded as a JavaScript array of objects in `script.js`. There is no backend or database — all data lives client-side.
- **Styling**: CSS uses custom properties (CSS variables) defined in `:root` for theming (primary color, secondary color, shadows, border radius). The font family is Poppins (loaded externally via Google Fonts presumably from the HTML file).
- **Design pattern**: The app follows a simple data-driven rendering approach where the `menus` array contains all menu items, each with properties like `id`, `titre`, `description`, `theme`, `regime`, `personnes`, `prix`, and `images`.

### Data Model
Each menu object has:
- `id` (number) — unique identifier
- `titre` (string) — menu name in French
- `description` (string) — description of the menu
- `theme` (string) — category like "Noël", "Pâques", "Classique"
- `regime` (string) — dietary type like "Classique", "Vegetarien"
- `personnes` (number) — number of people served
- `prix` (number) — price in euros
- `images` (array of strings) — Unsplash image URLs

### Key Notes
- The `script.js` file appears to be **truncated/incomplete** — it cuts off mid-object in the menus array. The agent should be aware that this file needs to be completed or fixed if modifications are made.
- There is no `index.html` file visible in the repository. One likely exists or needs to be created to tie together the CSS and JS files.
- The application is entirely in **French** — menu names, descriptions, and UI labels should remain in French unless the user requests otherwise.

## External Dependencies

- **Google Fonts (Poppins)**: Used for typography, referenced in CSS via `font-family: 'Poppins'`.
- **Unsplash**: Food images are hotlinked from Unsplash's CDN. No API key is used — these are direct image URLs.
- **No backend services**: No server, no database, no authentication. Everything runs in the browser.
- **No package manager**: No `package.json`, no npm dependencies. This is a pure static site.
const menus = [
    {
        id: 1,
        titre: "Menu Noël",
        description: "Dinde aux marrons, bûche maison et décorations festives pour 4 personnes.",
        theme: "Noël",
        regime: "Classique",
        personnes: 4,
        prix: 120,
        images: [
            "https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=500&q=60",
            "https://images.unsplash.com/photo-1578662996442-48f60103fc96?auto=format&fit=crop&w=500&q=60"
        ]
    },
    {
        id: 2,
        titre: "Menu Pâques",
        description: "Agneau pascal, œufs en chocolat et légumes printaniers pour 2 personnes.",
        theme: "Pâques",
        regime: "Vegetarien",
        personnes: 2,
        prix: 60,
        images: [
            "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?auto=format&fit=crop&w=500&q=60"
        ]
    },
    {
        id: 3,
        titre: "Menu Classique",
        description: "Plat du jour traditionnel, dessert maison et boisson fraîche. Ingrédients de saison.",
        theme: "Classique",
        regime: "Classique",
        personnes: 2,
        prix: 50,
        images: [
            "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=500&q=60",
            "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=500&q=60"
        ]
    },
    {
        id: 4,
        titre: "Menu Familial",
        description: "Entrée, plat, dessert et boissons pour 6 personnes. Idéal pour les repas en famille.",
        theme: "Classique",
        regime: "Classique",
        personnes: 6,
        prix: 150,
        images: [
            "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
            "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
        ]
    },
    {
        id: 5,
        titre: "Menu Végétarien",
        description: "Plats 100% végétariens pour 2 personnes, avec options sans gluten.",
        theme: "Classique",
        regime: "Vegetarien",
        personnes: 2,
        prix: 55,
        images: [
            "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
            "https://images.unsplash.com/photo-1547592180-85f173990554?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
        ]
    }
];

// Fonction pour convertir une valeur en nombre entier (sécurisé)
function safeParseInt(value) {
    const num = parseInt(value);
    return isNaN(num) ? 0 : num;
}

// Fonction pour afficher les menus
function afficherMenus(liste) {
    const container = document.getElementById("menus");
    container.innerHTML = "";

    if (liste.length === 0) {
        const noResults = document.createElement("p");
        noResults.className = "no-results";
        noResults.textContent = "Aucun menu trouvé. Essayez d'ajuster vos filtres.";
        container.appendChild(noResults);
        return;
    }

    liste.forEach(menu => {
        const card = document.createElement("div");
        card.className = "menu-card";

        card.innerHTML = `
            <img src="${menu.images[0]}" alt="${menu.titre}" onclick="openModal('${menu.images[0]}')">
            <div class="menu-card-content">
                <span class="menu-badge">${menu.theme}</span>
                <h3>${menu.titre}</h3>
                <p>${menu.description.substring(0, 80)}...</p>
                <p><strong>👥 ${menu.personnes} pers.</strong> | <strong>🥗 ${menu.regime}</strong></p>
            </div>
            <div class="menu-footer">
                <span class="price-tag">${menu.prix} €</span>
                <button class="view-btn" onclick="voirMenu(${menu.id})">Découvrir</button>
            </div>
        `;

        container.appendChild(card);
    });
}

// Fonction pour filtrer les menus
function filtrerMenus() {
    const button = document.querySelector("button");
    button.innerHTML = '<span class="loading"></span> Chargement...';
    button.disabled = true;

    setTimeout(() => {
        const prixMax = document.getElementById("prixMax").value;
        const theme = document.getElementById("theme").value;
        const regime = document.getElementById("regime").value;
        const personnesMin = document.getElementById("personnesMin").value;

        const resultats = menus.filter(menu => {
            return (
                (prixMax === "" || (safeParseInt(prixMax) > 0 && menu.prix <= safeParseInt(prixMax))) &&
                (theme === "" || menu.theme === theme) &&
                (regime === "" || menu.regime === regime) &&
                (personnesMin === "" || (safeParseInt(personnesMin) > 0 && menu.personnes >= safeParseInt(personnesMin)))
            );
        });

        afficherMenus(resultats);
        button.innerHTML = "Appliquer les filtres";
        button.disabled = false;
    }, 500);
}

// Fonction pour ouvrir le modal d'image
function openModal(imgSrc) {
    const modal = document.getElementById("imageModal");
    const modalImg = document.getElementById("modalImage");
    modal.style.display = "block";
    modalImg.src = imgSrc;
}

// Fermer le modal
document.querySelector(".close").onclick = function() {
    document.getElementById("imageModal").style.display = "none";
};

// Fermer le modal en cliquant en dehors de l'image
window.onclick = function(event) {
    const modal = document.getElementById("imageModal");
    if (event.target === modal) {
        modal.style.display = "none";
    }
};

// Fonction pour rediriger vers la page de détail
function voirMenu(id) {
    // Remplace par la vraie redirection quand tu auras créé menu_detail.php
    window.location.href = `menu_detail.php?id=${id}`;
   
}

afficherMenus(menus);
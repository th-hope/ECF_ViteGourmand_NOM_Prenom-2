<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Vite & Gourmand</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <div class="logo" style="display: flex; align-items: center; color: white; font-weight: 600; font-size: 1.2rem;">
            <img src="logo.png" alt="Logo" style="height: 40px; margin-right: 10px;">
            Vite & Gourmand
        </div>
        <div class="nav-links">
            <a href="index.php">Accueil</a>
            <a href="index.php#menus">Menus</a>
            <a href="contact.php">Contact</a>
        </div>
    </nav>

    <div class="container" style="max-width: 400px; margin-top: 8rem;">
        <div style="background: white; padding: 2.5rem; border-radius: var(--radius); box-shadow: var(--shadow); text-align: center;">
            <h1 style="color: var(--primary-color); margin-bottom: 1rem;">Connexion</h1>
            <p style="color: #666; margin-bottom: 2rem;">Accédez à votre espace Julie & José</p>
            
            <form action="#" method="POST" onsubmit="alert('Connexion réussie ! Bienvenue dans votre espace.'); window.location.href='index.php'; return false;">
                <div class="filter-group" style="margin-bottom: 1.5rem; text-align: left;">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required placeholder="votre@email.com">
                </div>
                <div class="filter-group" style="margin-bottom: 2rem; text-align: left;">
                    <label for="password">Mot de passe</label>
                    <input type="password" id="password" name="password" required placeholder="••••••••">
                </div>
                <button type="submit" style="width: 100%;">Se connecter</button>
            </form>
            
            <p style="margin-top: 1.5rem; font-size: 0.9rem; color: #888;">
                Pas encore de compte ? <a href="#" style="color: var(--secondary-color); text-decoration: none; font-weight: 600;">S'inscrire</a>
            </p>
        </div>
    </div>

    <footer class="footer" style="margin-top: 8rem; padding: 2rem; background: var(--primary-color); color: white; text-align: center; border-radius: var(--radius) var(--radius) 0 0;">
        <p style="font-size: 0.8rem; color: #7f8c8d;">&copy; 2026 Vite & Gourmand - Propulsé par FAST DEV</p>
    </footer>
</body>
</html>
<?php
// On simule une base de données avec un tableau
$menus = [
    [
        "id" => 1,
        "titre" => "Menu Noël",
        "description" => "Dinde aux marrons, bûche maison et décorations festives pour 4 personnes. Un menu traditionnel pour célébrer les fêtes en famille.",
        "theme" => "Noël",
        "regime" => "Classique",
        "personnes" => 4,
        "prix" => 120,
        "images" => [
            "https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1578662996442-48f60103fc96?auto=format&fit=crop&w=800&q=80"
        ],
        "plats" => [
            "entree" => "Foie gras maison avec toasts",
            "plat" => "Dinde aux marrons et pommes de terre rôties",
            "dessert" => "Bûche de Noël traditionnelle"
        ],
        "allergenes" => ["Gluten", "Lait", "Œufs", "Noix"]
    ],
    [
        "id" => 2,
        "titre" => "Menu Pâques",
        "description" => "Agneau pascal, œufs en chocolat et légumes printaniers pour 2 personnes. Une célébration gourmande du printemps.",
        "theme" => "Pâques",
        "regime" => "Vegetarien",
        "personnes" => 2,
        "prix" => 60,
        "images" => [
            "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1587668178277-295251f900ce?auto=format&fit=crop&w=800&q=80"
        ],
        "plats" => [
            "entree" => "Velouté de potimarron aux graines de courge",
            "plat" => "Quiche aux asperges et fromage de chèvre",
            "dessert" => "Œufs en chocolat noir et lait"
        ],
        "allergenes" => ["Lait", "Œufs", "Gluten"]
    ],
    [
        "id" => 3,
        "titre" => "Menu Classique",
        "description" => "Plat du jour traditionnel, dessert maison et boisson fraîche. Ingrédients de saison.",
        "theme" => "Classique",
        "regime" => "Classique",
        "personnes" => 2,
        "prix" => 50,
        "images" => [
            "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=80"
        ],
        "plats" => [
            "entree" => "Salade de saison croquante",
            "plat" => "Steak frites maison ou Poisson du jour",
            "dessert" => "Tartelette aux fruits"
        ],
        "allergenes" => ["Gluten", "Lait"]
    ],
    [
        "id" => 4,
        "titre" => "Menu Familial",
        "description" => "Entrée, plat, dessert et boissons pour 6 personnes. Idéal pour les repas en famille.",
        "theme" => "Classique",
        "regime" => "Classique",
        "personnes" => 6,
        "prix" => 150,
        "images" => [
            "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80"
        ],
        "plats" => [
            "entree" => "Planche de charcuterie et fromages",
            "plat" => "Poulet rôti fermier et gratin dauphinois",
            "dessert" => "Gâteau au chocolat familial"
        ],
        "allergenes" => ["Lait", "Gluten"]
    ],
    [
        "id" => 5,
        "titre" => "Menu Végétarien",
        "description" => "Plats 100% végétariens pour 2 personnes, avec options sans gluten.",
        "theme" => "Classique",
        "regime" => "Vegetarien",
        "personnes" => 2,
        "prix" => 55,
        "images" => [
            "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=800&q=80"
        ],
        "plats" => [
            "entree" => "Houmous maison et pain pita",
            "plat" => "Risotto aux champignons sauvages",
            "dessert" => "Salade de fruits frais de saison"
        ],
        "allergenes" => ["Sésame", "Lait"]
    ]
];

// Récupération de l'ID depuis l'URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$menu = null;

foreach ($menus as $m) {
    if ($m['id'] === $id) {
        $menu = $m;
        break;
    }
}

if (!$menu) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($menu['titre']); ?> - Vite & Gourmand</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --success-color: #27ae60;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--dark-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        nav {
            background-color: var(--primary-color);
            color: white;
            padding: 1rem 0;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 1rem;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            margin-bottom: 2rem;
            text-decoration: none;
            color: var(--primary-color);
            font-weight: 500;
            transition: all 0.3s;
            padding: 0.5rem 1rem;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .back-button:hover {
            color: var(--secondary-color);
            transform: translateX(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .detail-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin-bottom: 3rem;
        }

        .image-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1rem;
            padding: 1rem;
        }

        .image-gallery img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .image-gallery img:hover {
            transform: scale(1.03);
        }

        .main-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
            cursor: pointer;
        }

        .menu-details {
            padding: 2rem;
        }

        .menu-title {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .menu-description {
            font-size: 1.1rem;
            margin-bottom: 2rem;
            color: #555;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .info-card {
            background: var(--light-color);
            padding: 1rem;
            border-radius: 8px;
        }

        .info-card h3 {
            margin-top: 0;
            color: var(--primary-color);
        }

        .plats-list {
            background: var(--light-color);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
        }

        .plats-list h3 {
            margin-top: 0;
            color: var(--primary-color);
        }

        .plats-list ul {
            padding-left: 1.5rem;
        }

        .plats-list li {
            margin-bottom: 0.5rem;
        }

        .allergenes {
            background: #fff8f8;
            padding: 1rem;
            border-radius: 8px;
            border-left: 4px solid var(--secondary-color);
        }

        .allergenes h3 {
            margin-top: 0;
            color: var(--secondary-color);
        }

        .allergenes span {
            display: inline-block;
            background: var(--secondary-color);
            color: white;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .commander-btn {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
        }

        .commander-btn:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
        }

        .commander-btn:active {
            transform: translateY(0);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
            overflow: auto;
        }

        .modal-content {
            display: block;
            margin: auto;
            max-width: 90%;
            max-height: 80vh;
            margin-top: 5vh;
            border-radius: 8px;
        }

        .close {
            position: absolute;
            top: 20px;
            right: 30px;
            color: #fff;
            font-size: 35px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover {
            color: #ccc;
        }

        @media (max-width: 768px) {
            .image-gallery {
                grid-template-columns: 1fr;
            }

            .main-image {
                height: 300px;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav>
        <div class="container" style="display: flex; justify-content: space-between; align-items: center;">
            <div class="logo" style="display: flex; align-items: center; font-weight: 600; font-size: 1.2rem;">
                <img src="logo.png" alt="Logo" style="height: 40px; margin-right: 10px;">
                Vite & Gourmand
            </div>
            <div class="nav-links">
                <a href="index.php">Accueil</a>
                <a href="index.php#menus">Nos Menus</a>
                <a href="contact.php">Contact</a>
                <a href="login.php">Connexion</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="detail-container">
            <a href="index.php" class="back-button">
                <span>←</span> Retour aux menus
            </a>

            <!-- Galerie d'images -->
            <div class="image-gallery">
                <?php foreach ($menu['images'] as $index => $image): ?>
                    <img
                        src="<?php echo htmlspecialchars($image); ?>"
                        alt="<?php echo htmlspecialchars($menu['titre'] . ' - Image ' . ($index + 1)); ?>"
                        onclick="openModal('<?php echo htmlspecialchars($image); ?>')"
                        onerror="this.src='https://via.placeholder.com/400x300?text=Image+indisponible'; this.onerror=null;"
                    >
                <?php endforeach; ?>
            </div>

            <!-- Détails du menu -->
            <div class="menu-details">
                <h1 class="menu-title"><?php echo htmlspecialchars($menu['titre']); ?></h1>
                <p class="menu-description"><?php echo htmlspecialchars($menu['description']); ?></p>

                <div class="info-grid">
                    <div class="info-card">
                        <h3>Prix</h3>
                        <p><?php echo htmlspecialchars($menu['prix']); ?> €</p>
                    </div>
                    <div class="info-card">
                        <h3>Nombre de personnes</h3>
                        <p><?php echo htmlspecialchars($menu['personnes']); ?></p>
                    </div>
                    <div class="info-card">
                        <h3>Thème</h3>
                        <p><?php echo htmlspecialchars($menu['theme']); ?></p>
                    </div>
                    <div class="info-card">
                        <h3>Régime</h3>
                        <p><?php echo htmlspecialchars($menu['regime']); ?></p>
                    </div>
                </div>

                <div class="plats-list">
                    <h3>Composition du menu</h3>
                    <ul>
                        <li><strong>Entrée :</strong> <?php echo htmlspecialchars($menu['plats']['entree']); ?></li>
                        <li><strong>Plat :</strong> <?php echo htmlspecialchars($menu['plats']['plat']); ?></li>
                        <li><strong>Dessert :</strong> <?php echo htmlspecialchars($menu['plats']['dessert']); ?></li>
                    </ul>
                </div>

                <div class="allergenes">
                    <h3>Allergènes</h3>
                    <?php foreach ($menu['allergenes'] as $allergen): ?>
                        <span><?php echo htmlspecialchars($allergen); ?></span>
                    <?php endforeach; ?>
                </div>

                <button class="commander-btn" onclick="alert('Commande du menu <?php echo htmlspecialchars($menu['titre']); ?> enregistrée !')">
                    Commander ce menu
                </button>
            </div>
        </div>
    </div>

    <!-- Modal pour afficher les images en grand -->
    <div id="imageModal" class="modal">
        <span class="close">&times;</span>
        <img class="modal-content" id="modalImage">
    </div>

    <footer class="footer" style="margin-top: 5rem; padding: 4rem 2rem; background: #2c3e50; color: white; border-radius: 12px 12px 0 0;">
        <div class="container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem;">
            <div>
                <h4 style="color: #e74c3c; margin-bottom: 1.5rem;">Vite & Gourmand</h4>
                <p style="color: #bdc3c7; font-size: 0.9rem;">Votre traiteur gastronomique à Bordeaux depuis 25 ans. Julie & José à votre service.</p>
            </div>
            <div>
                <h4 style="margin-bottom: 1.5rem; color: white;">Liens Rapides</h4>
                <ul style="list-style: none; padding: 0;">
                    <li style="margin-bottom: 0.5rem;"><a href="index.php" style="color: #bdc3c7; text-decoration: none; font-size: 0.9rem;">Accueil</a></li>
                    <li style="margin-bottom: 0.5rem;"><a href="index.php#menus" style="color: #bdc3c7; text-decoration: none; font-size: 0.9rem;">Nos Menus</a></li>
                    <li style="margin-bottom: 0.5rem;"><a href="contact.php" style="color: #bdc3c7; text-decoration: none; font-size: 0.9rem;">Contact</a></li>
                </ul>
            </div>
            <div>
                <h4 style="margin-bottom: 1.5rem; color: white;">Contact Bordeaux</h4>
                <p style="color: #bdc3c7; font-size: 0.9rem;">📍 45 Rue des Grands Crus, Bordeaux</p>
                <p style="color: #bdc3c7; font-size: 0.9rem;">📞 05 56 00 00 00</p>
            </div>
        </div>
        <div style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.1); text-align: center; color: #7f8c8d; font-size: 0.8rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
            <span>&copy; 2026 Vite & Gourmand. Tous droits réservés.</span>
            <span style="color: #bdc3c7;">Développé par <strong style="color: #e74c3c;">FAST DEV</strong></span>
        </div>
    </footer>

    <script>
        // Fonction pour ouvrir le modal
        function openModal(imgSrc) {
            const modal = document.getElementById("imageModal");
            const modalImg = document.getElementById("modalImage");
            modal.style.display = "block";
            modalImg.src = imgSrc;
            document.body.style.overflow = "hidden"; // Empêche le scroll en arrière-plan
        }

        // Fermer le modal
        document.querySelector(".close").onclick = function() {
            document.getElementById("imageModal").style.display = "none";
            document.body.style.overflow = "auto";
        };

        // Fermer le modal en cliquant en dehors de l'image
        window.onclick = function(event) {
            const modal = document.getElementById("imageModal");
            if (event.target === modal) {
                modal.style.display = "none";
                document.body.style.overflow = "auto";
            }
        };
    </script>
</body>
</html>
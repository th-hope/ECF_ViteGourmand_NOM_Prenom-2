<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menus - Vite & Gourmand</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <div class="logo" style="display: flex; align-items: center; color: white; font-weight: 600; font-size: 1.2rem;">
            <img src="logo.png" alt="Logo" style="height: 40px; margin-right: 10px;">
            Vite & Gourmand
        </div>
        <div class="nav-links">
            <a href="index.php">Accueil</a>
            <a href="index.php#menus">Menus</a>
            <a href="contact.php">Contact</a>
            <a href="login.php" class="login-link">Connexion</a>
        </div>
    </nav>

    <div class="container">
        <h1 id="menus">Nos menus</h1>

        <div class="filters">
            <h3>Filtres</h3>
            <div class="filters-row">
                <div class="filter-group">
                    <label for="prixMax">Prix maximum (€)</label>
                    <input type="number" id="prixMax" placeholder="Ex: 100" aria-label="Prix maximum">
                </div>
                <div class="filter-group">
                    <label for="theme">Thème</label>
                    <select id="theme">
                        <option value="">Tous</option>
                        <option value="Noël">Noël</option>
                        <option value="Pâques">Pâques</option>
                        <option value="Classique">Classique</option>
                        <option value="Événement">Événement</option>
                    </select>
                </div>
            </div>
            <div class="filters-row">
                <div class="filter-group">
                    <label for="regime">Régime</label>
                    <select id="regime">
                        <option value="">Tous</option>
                        <option value="Classique">Classique</option>
                        <option value="Vegetarien">Végétarien</option>
                        <option value="Vegan">Vegan</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="personnesMin">Personnes minimum</label>
                    <input type="number" id="personnesMin" placeholder="Ex: 2">
                </div>
            </div>
            <button onclick="filtrerMenus()">Appliquer les filtres</button>
        </div>

        <div id="menus"></div>

        <section class="chef-section" style="margin-top: 5rem; padding: 4rem 2rem; background: white; border-radius: var(--radius); box-shadow: var(--shadow); display: flex; align-items: center; gap: 3rem; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 300px;">
                <img src="chefs.png" alt="Julie & José" style="width: 100%; border-radius: var(--radius); object-fit: cover; height: 400px;">
            </div>
            <div style="flex: 1.5; min-width: 300px;">
                <span style="color: var(--secondary-color); font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Le Mot de Julie & José</span>
                <h2 style="font-size: 2.5rem; margin: 1rem 0; color: var(--primary-color);">25 ans de passion à Bordeaux</h2>
                <p style="font-size: 1.1rem; color: #666; margin-bottom: 2rem;">"Depuis 25 ans, nous mettons notre savoir-faire au service de vos plus beaux événements à Bordeaux. Que ce soit pour un repas de Noël, de Pâques ou toute autre occasion, nos menus évoluent sans cesse pour vous offrir le meilleur de la gastronomie locale."</p>
                <div style="display: flex; gap: 1rem; align-items: center;">
                    <div style="width: 60px; height: 60px; background: #eee; border-radius: 50%; overflow: hidden;">
                        <img src="chefs.png" alt="Julie & José Portrait" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    <div>
                        <strong style="display: block; color: var(--primary-color);">Julie & José</strong>
                        <small style="color: #888;">Fondateurs & Passionnés</small>
                    </div>
                </div>
            </div>
        </section>

        <footer class="footer" style="margin-top: 5rem; padding: 4rem 2rem; background: var(--primary-color); color: white; border-radius: var(--radius) var(--radius) 0 0;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem;">
                <div>
                    <h4 style="color: var(--secondary-color); margin-bottom: 1.5rem;">Vite & Gourmand</h4>
                    <p style="color: #bdc3c7; font-size: 0.9rem;">Votre traiteur gastronomique à Bordeaux depuis 25 ans. Des produits frais, une passion intacte pour tous vos événements.</p>
                </div>
                <div>
                    <h4 style="margin-bottom: 1.5rem;">Liens Rapides</h4>
                    <ul style="list-style: none; padding: 0;">
                        <li style="margin-bottom: 0.5rem;"><a href="index.php" style="color: #bdc3c7; text-decoration: none; font-size: 0.9rem;">Accueil</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="#menus" style="color: #bdc3c7; text-decoration: none; font-size: 0.9rem;">Nos Menus</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="contact.php" style="color: #bdc3c7; text-decoration: none; font-size: 0.9rem;">Contact</a></li>
                    </ul>
                </div>
                <div>
                    <h4 style="margin-bottom: 1.5rem;">Contact</h4>
                    <p style="color: #bdc3c7; font-size: 0.9rem;">📍 45 Rue des Grands Crus, Bordeaux</p>
                    <p style="color: #bdc3c7; font-size: 0.9rem;">📞 05 56 00 00 00</p>
                    <p style="color: #bdc3c7; font-size: 0.9rem;">✉️ contact@viteetgourmand.fr</p>
                </div>
            </div>
            <div style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.1); text-align: center; color: #7f8c8d; font-size: 0.8rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
                <span>&copy; 2026 Vite & Gourmand. Tous droits réservés.</span>
                <span style="color: #bdc3c7;">Développé avec passion par <strong style="color: var(--secondary-color);">FAST DEV</strong></span>
            </div>
        </footer>
    </div>

    <div id="imageModal" class="modal">
        <span class="close">&times;</span>
        <img class="modal-content" id="modalImage">
    </div>

    <script src="script.js"></script>
</body>
</html>
